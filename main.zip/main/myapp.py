from flask import Flask, render_template, request, send_file, jsonify
from pathlib import Path
from omegaconf import OmegaConf
from sampler import ResShiftSampler
from utils import util_image
from basicsr.utils.download_util import load_file_from_url
import os
import threading
from forms import RegisterForm, LoginForm
from exts import db, mail
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_mail import Message, Mail
from mymodel import UserModel, EmailCaptchaModel
from werkzeug.security import generate_password_hash, check_password_hash
import string
import random

app = Flask(__name__)

app.secret_key = 'your_secret_key'  # 设置 Flask 应用的密钥

# 数据库配置
HOSTNAME = '127.0.0.1'
PORT = '3306'
DATABASE = 'resshift'
USERNAME = 'root'
PASSWORD = 'ai2022'

app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{USERNAME}:{PASSWORD}@{HOSTNAME}:{PORT}/{DATABASE}?charset=utf8mb4"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Flask-Mail 配置
app.config['MAIL_SERVER'] = 'smtp.qq.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = '1269093437@qq.com'  # 你的QQ邮箱
app.config['MAIL_PASSWORD'] = 'oitphiuqyjjxifce'  # 你的QQ邮箱授权码
app.config['MAIL_DEFAULT_SENDER'] = '1269093437@qq.com'

# 初始化扩展
db.init_app(app)  # 初始化数据库
mail.init_app(app)  # 初始化邮件服务

# 创建数据库表（如果使用 Flask-Migrate，可以跳过这一步）
with app.app_context():
    db.create_all()


# 文件夹设置
UPLOAD_FOLDER = './static/uploads'
OUTPUT_FOLDER = './static/output'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# 文件编号计数器
file_counter = 0
file_counter_lock = threading.Lock()

_STEP = {'v3': 4, 'bicsr': 4}
_LINK = {
    'vqgan': 'https://github.com/zsyOAOA/ResShift/releases/download/v2.0/autoencoder_vq_f4.pth',
    'v3': 'https://github.com/zsyOAOA/ResShift/releases/download/v2.0/resshift_realsrx4_s4_v3.pth',
    'bicsr': 'https://github.com/zsyOAOA/ResShift/releases/download/v2.0/resshift_bicsrx4_s4.pth',
}

def get_configs(task='realsr', version='v3', scale=4):
    ckpt_dir = Path('./weights')
    ckpt_dir.mkdir(exist_ok=True)

    if task == 'realsr':
        configs = OmegaConf.load('./configs/realsr_swinunet_realesrgan256_journal.yaml')
        ckpt_url = _LINK[version]
        ckpt_path = ckpt_dir / f'resshift_{task}x{scale}_s{_STEP[version]}_{version}.pth'
        vqgan_url = _LINK['vqgan']
        vqgan_path = ckpt_dir / 'autoencoder_vq_f4.pth'
    elif task == 'bicsr':
        configs = OmegaConf.load('./configs/bicx4_swinunet_lpips.yaml')
        ckpt_url = _LINK[task]
        ckpt_path = ckpt_dir / f'resshift_{task}x{scale}_s{_STEP[task]}.pth'
        vqgan_url = _LINK['vqgan']
        vqgan_path = ckpt_dir / 'autoencoder_vq_f4.pth'
    else:
        raise ValueError(f"Unsupported task: {task}")

    if not ckpt_path.exists():
        load_file_from_url(ckpt_url, model_dir=ckpt_dir, progress=True, file_name=ckpt_path.name)
    if not vqgan_path.exists():
        load_file_from_url(vqgan_url, model_dir=ckpt_dir, progress=True, file_name=vqgan_path.name)

    configs.model.ckpt_path = str(ckpt_path)
    configs.diffusion.params.sf = scale
    configs.autoencoder.ckpt_path = str(vqgan_path)

    return configs

def predict(input_path, task='realsr', seed=12345, scale=4, version='v3'):
    configs = get_configs(task, version, scale)
    sampler = ResShiftSampler(configs, sf=scale, chop_size=256, chop_stride=224, chop_bs=1, use_amp=True, seed=seed)
    sampler.inference(input_path, OUTPUT_FOLDER, mask_path=None, bs=1, noise_repeat=False)
    output_path = os.path.join(OUTPUT_FOLDER, f"{Path(input_path).stem}.png")
    if not Path(output_path).exists():
        raise RuntimeError("Prediction failed")
    return output_path

@app.route('/')
def index():
    return redirect(url_for('register'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()  # 实例化表单对象
    if request.method == 'POST':
        if form.validate():  # 验证表单
            email = form.email.data
            username = form.username.data
            password = form.password.data
            captcha = form.captcha.data

            # 验证验证码
            captcha_model = EmailCaptchaModel.query.filter_by(email=email).first()
            if not captcha_model or captcha_model.captcha != captcha:
                flash("验证码错误！", "error")
                return redirect(url_for('register'))

            # 创建用户
            user = UserModel(email=email, username=username, password=generate_password_hash(password))
            db.session.add(user)
            db.session.commit()  # 提交数据库事务

            # 注册成功后跳转到登录页面
            flash("注册成功，请登录！", "success")
            return redirect(url_for('login'))
        else:
            flash(list(form.errors.values())[0][0], "error")
            return redirect(url_for('register'))
    return render_template('register.html', form=form)  # 传递表单对象

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()  # 实例化表单对象
    if request.method == 'POST':
        if form.validate():  # 验证表单
            email = form.email.data
            password = form.password.data

            # 验证用户是否存在
            user = UserModel.query.filter_by(email=email).first()
            if not user:
                flash("邮箱在数据库中不存在！", "error")
                return render_template('login.html', form=form)

            # 验证密码是否正确
            if check_password_hash(user.password, password):
                session['user_id'] = user.id
                flash("登录成功！", "success")
                return redirect(url_for('dashboard'))  # 跳转到登录成功页面
            else:
                flash("账号或密码错误！", "error")
                return redirect(url_for('login'))
        else:
            flash(list(form.errors.keys())[0], "error")
            return redirect(url_for('login'))
    return render_template('login.html', form=form)  # 传递表单对象


@app.route('/captcha/email', methods=['GET'])
def get_email_captcha():
    email = request.args.get('email')
    source = string.digits * 6
    captcha = ''.join(random.sample(source, 6))

    try:
        # 发送邮件
        message = Message(subject="注册验证码", recipients=[email], body=f"您的验证码是：{captcha}")
        mail.send(message)

        # 存储验证码
        captcha_model = EmailCaptchaModel.query.filter_by(email=email).first()
        if captcha_model:
            # 如果验证码已存在，更新验证码
            captcha_model.captcha = captcha
        else:
            # 如果验证码不存在，创建新的验证码
            captcha_model = EmailCaptchaModel(email=email, captcha=captcha)
        db.session.add(captcha_model)
        db.session.commit()

        return jsonify({'code': 200, 'message': '验证码发送成功', 'data': None})
    except Exception as e:
        return jsonify({'code': 500, 'message': f'验证码发送失败: {str(e)}', 'data': None})

@app.route('/dashboard')
def dashboard():
    if 'user_id' in session:
        return render_template('home.html')
    else:
        flash("请先登录！", "error")
        return redirect(url_for('login'))

@app.route('/mail/test')
def mail_test():
    try:
        message = Message(
            subject="测试邮件",
            recipients=["1269093437@qq.com"],  # 你的QQ邮箱
            body="这是一封测试邮件，请忽略。"
        )
        mail.send(message)
        return "邮件发送成功"
    except Exception as e:
        return f"邮件发送失败: {str(e)}"

@app.route('/upload', methods=['POST'])
def upload():
    global file_counter

    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    file = request.files['file']
    task = request.form.get('task', 'realsr')
    seed = int(request.form.get('seed', 12345))

    # 生成文件编号
    with file_counter_lock:
        file_counter += 1
        file_name = f"{file_counter}.png"
        input_path = os.path.join(UPLOAD_FOLDER, file_name)

    # 保存文件
    file.save(input_path)

    try:
        output_path = predict(input_path, task, seed, scale=4, version='v3')
        return jsonify({'output_url': f'/static/output/{Path(output_path).name}'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/download/<filename>')
def download(filename):
    file_path = os.path.join(OUTPUT_FOLDER, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    return jsonify({'error': 'File not found'}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5000,debug=True)
